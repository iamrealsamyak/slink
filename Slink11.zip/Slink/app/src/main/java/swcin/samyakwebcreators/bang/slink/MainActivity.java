package swcin.samyakwebcreators.bang.slink;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;



public class MainActivity extends AppCompatActivity {



    private WebView wv;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //FAB
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wv.reload();
            }
        });
        //FAB END

// Web View
        wv = (WebView) findViewById(R.id.webview);


        wv.setWebViewClient(new WebViewClient());
        WebSettings webSettings = wv.getSettings();
        webSettings.setJavaScriptEnabled(true);
        wv.getSettings().setAppCachePath(getApplicationContext().getFilesDir().getAbsolutePath() + "/cache");
        wv.getSettings().setDatabasePath(getApplicationContext().getFilesDir().getAbsolutePath() + "/databases");

        ConnectivityManager connectivityManager = (ConnectivityManager)
                getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() || !networkInfo.isAvailable()) {

            wv.loadUrl("file:///android_asset/offline.html");

        } else {

            wv.loadUrl("https://atopin.weebly.com");
        }

    }
// Web View End
    //MENU

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.super_menu, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_forward:
                onForwardPressed();
                return true;

            case R.id.menu_about:
                onAboutPressed();
                return true;

            case R.id.menu_home:
                onNewPressed();
                return true;
            case R.id.menu_back:
                onBackMenuPressed();
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
        }

    private void onForwardPressed(){

        if(wv.canGoForward()){

            wv.goForward();

        } else{
            Toast.makeText(this, "Can't go Forward Anymore !", Toast.LENGTH_SHORT).show();
        }

    }
    private void onBackMenuPressed(){

        if(wv.canGoBack()){

            wv.goBack();

        } else{
            Toast.makeText(this, "Can't go Backward Anymore !", Toast.LENGTH_SHORT).show();
        }

    }
    private void onAboutPressed(){

        Intent homeIntent = new Intent(MainActivity.this, AboutActivity.class);
        startActivity(homeIntent);
    }
    private void onHomePressed(){

        Intent homeIntent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(homeIntent);
    }
    private void onNewPressed(){

        Intent homeIntent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(homeIntent);
    }
//MENU END

    //BACK KEY
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && wv.canGoBack()) {
            wv.goBack();
            return true;
        }
        // If it wasn't the Back key or there's no web page history, bubble up to the default
        // system behavior (probably exit the activity)
        return super.onKeyDown(keyCode, event);
    }
}